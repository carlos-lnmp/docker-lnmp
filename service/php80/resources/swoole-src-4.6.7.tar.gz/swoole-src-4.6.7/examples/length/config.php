<?php
$loop1 = 1;
$loop2 = 3;
